ToggleSwitch = CustomItem:extend()

function ToggleSwitch:init(name, code, imagePathA, imagePathB, defaultState, itemType)
    self:createItem(name)
    self.code = code
    self:setProperty("active", defaultState)
    self:setProperty("defaultIcon", true)
    self.activeImage = ImageReference:FromPackRelativePath(imagePathA)
    self.ItemInstance.PotentialIcon = self.activeImage
    self.defaultIcon = true
    
    self.imageA = ImageReference:FromPackRelativePath(imagePathA)
    self.imageADisabled = ImageReference:FromPackRelativePath(imagePathA, "@disabled")
    self.imageB = ImageReference:FromPackRelativePath(imagePathB)
    self.imageBDisabled = ImageReference:FromPackRelativePath(imagePathB, "@disabled")

    self.itemType = itemType
    self.ItemInstance.Icon = self.activeImage
    self:updateIcon()

    self:propertyChanged(self.active, true)
    self:propertyChanged(self.active, false)

end

function ToggleSwitch:setActive(active)
    self:setProperty("active", active)
end

function ToggleSwitch:getActive()
    return self:getProperty("active")
end

function ToggleSwitch:updateIcon()
    if self:getActive() then
        if self:getProperty("defaultIcon") then
            self.ItemInstance.Icon = self.imageA
        else
            self.ItemInstance.Icon = self.imageB
        end
    else
        if self:getProperty("defaultIcon") then
            self.ItemInstance.Icon = self.imageADisabled
        else
            self.ItemInstance.Icon = self.imageBDisabled
        end
    end

    print(self:getActive())
end

function ToggleSwitch:onLeftClick()
    self:setActive(not self:getActive())
    print(self:getActive())
end

function ToggleSwitch:onRightClick()
    self:setActive(not self:getActive())
end

function ToggleSwitch:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function ToggleSwitch:providesCode(code)
    if code == self.code and self.getActive() then
        return 1
    end
    return 0
end

function ToggleSwitch:advanceToCode(code)
    if code == nil or code == self.code then
        self:setActive(true)
    end
end

function ToggleSwitch:save()
    local data = {}
    data["active"] = self:getActive()
    data["defaultIcon"] = self:getProperty("defaultIcon")
    return data
end

function ToggleSwitch:load(data)
    if data["active"] ~= nil then
        
        self:setActive(data["active"])
        self:setProperty(data["defaultIcon"])
    end

    self:updateIcon()
    return true
end

function ToggleSwitch:propertyChanged(key, value)
    self:updateIcon()
end